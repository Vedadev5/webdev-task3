class AdvancedTaskManager {
    constructor() {
        this.tasks = this.loadTasks();
        this.currentFilter = 'all';
        this.searchQuery = '';
        this.isCollapsed = false;
        this.editingTaskId = null;
        this.currentSort = 'created';
        this.viewMode = 'card';

        this.initializeElements();
        this.bindEvents();
        this.initializeTheme();
        this.renderTasks();
    }

    // --- DOM Element Initialization ---
    initializeElements() {
        this.taskForm = document.getElementById('task-form');
        this.taskInput = document.getElementById('task-input');
        this.prioritySelect = document.getElementById('priority-select');
        this.categorySelect = document.getElementById('category-select');
        this.dueDateInput = document.getElementById('due-date');
        this.taskList = document.getElementById('task-list');
        this.searchInput = document.getElementById('search-input');
        this.filterButtons = document.querySelectorAll('.filter-btn');
        this.sortSelect = document.getElementById('sort-select');
        this.themeToggle = document.getElementById('theme-toggle');
        this.collapseToggle = document.getElementById('collapse-toggle');
        this.collapseIcon = document.getElementById('collapse-icon');
        this.taskListContainer = document.getElementById('task-list-container');
        this.notificationContainer = document.getElementById('notification-container');
        this.fab = document.getElementById('fab');
        this.voiceSearchBtn = document.getElementById('voice-search');
    }

    // --- Event Listener Binding ---
    bindEvents() {
        this.taskForm.addEventListener('submit', (e) => this.handleSubmit(e));
        this.searchInput.addEventListener('input', (e) => this.handleSearch(e));
        this.sortSelect.addEventListener('change', (e) => this.handleSort(e));
        this.themeToggle.addEventListener('click', () => this.toggleTheme());
        this.collapseToggle.addEventListener('click', () => this.toggleCollapse());
        this.fab.addEventListener('click', () => this.focusTaskInput());
        this.voiceSearchBtn.addEventListener('click', () => this.startVoiceSearch());
        this.filterButtons.forEach(btn => {
            btn.addEventListener('click', (e) => this.handleFilter(e.currentTarget));
        });
        document.addEventListener('keydown', (e) => this.handleKeyboard(e));
    }

    // --- Core Task Management ---
    handleSubmit(e) {
        e.preventDefault();
        const taskText = this.taskInput.value.trim();
        if (taskText) {
            const taskData = {
                text: taskText,
                priority: this.prioritySelect.value,
                category: this.categorySelect.value,
                dueDate: this.dueDateInput.value || null
            };
            if (this.editingTaskId) {
                this.updateTask(this.editingTaskId, taskData);
            } else {
                this.addTask(taskData);
            }
            this.resetForm();
        }
    }

    addTask(taskData) {
        const newTask = {
            id: Date.now().toString(),
            ...taskData,
            completed: false,
            createdAt: new Date().toISOString(),
            completedAt: null
        };
        this.tasks.unshift(newTask);
        this.saveAndRerender();
        this.showAdvancedNotification('Awesome task created! 🚀', 'success');
    }

    updateTask(id, updates) {
        let task = this.tasks.find(t => t.id === id);
        if (task) {
            Object.assign(task, updates);
            this.editingTaskId = null;
            this.saveAndRerender();
            this.showAdvancedNotification('Task updated successfully! ✅', 'success');
        }
    }

    deleteTask(id) {
        this.tasks = this.tasks.filter(task => task.id !== id);
        this.saveAndRerender();
        this.showAdvancedNotification('Task deleted! 🗑️', 'error');
    }

    toggleTask(id) {
        let task = this.tasks.find(t => t.id === id);
        if (task) {
            task.completed = !task.completed;
            task.completedAt = task.completed ? new Date().toISOString() : null;
            const message = task.completed ? 'Task completed! Great job! 🎉' : 'Task reopened! 📂';
            this.showAdvancedNotification(message, task.completed ? 'success' : 'info');
            this.saveAndRerender();
        }
    }

    editTask(id) {
        const task = this.tasks.find(t => t.id === id);
        if (task) {
            this.taskInput.value = task.text;
            this.prioritySelect.value = task.priority;
            this.categorySelect.value = task.category;
            this.dueDateInput.value = task.dueDate ? task.dueDate.slice(0, 16) : '';
            this.editingTaskId = id;
            this.focusTaskInput();
            this.taskForm.querySelector('button[type="submit"] > span:first-child').textContent = 'Update Task';
        }
    }

    // --- UI and Event Handlers ---
    handleFilter(button) {
        this.filterButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        this.currentFilter = button.dataset.filter;
        this.renderTasks();
    }
    
    handleSearch(e) {
        this.searchQuery = e.target.value.toLowerCase();
        this.renderTasks();
    }
    
    handleSort(e) {
        this.currentSort = e.target.value;
        this.renderTasks();
    }

    toggleCollapse() {
        this.isCollapsed = !this.isCollapsed;
        if (this.isCollapsed) {
            this.taskListContainer.style.maxHeight = '0px';
            this.collapseIcon.style.transform = 'rotate(-90deg)';
        } else {
            this.taskListContainer.style.maxHeight = this.taskList.scrollHeight + 'px';
            this.collapseIcon.style.transform = 'rotate(0deg)';
        }
    }
    
    toggleTheme() {
        document.documentElement.classList.toggle('dark');
        const isDark = document.documentElement.classList.contains('dark');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
        this.updateFilterButtonStyles();
    }

    // --- Rendering Logic ---
    renderTasks() {
        const filteredAndSortedTasks = this.getFilteredTasks();
        this.taskList.innerHTML = filteredAndSortedTasks.map(task => this.createAdvancedTaskHTML(task)).join('');
        this.updateStats();
        this.updateEmptyState(filteredAndSortedTasks.length);
    }
    
    // THIS IS THE CRITICAL FUNCTION THAT WAS MISSING
    createAdvancedTaskHTML(task) {
        const isOverdue = !task.completed && task.dueDate && new Date(task.dueDate) < new Date();
        const dueDate = task.dueDate ? new Date(task.dueDate).toLocaleString() : 'No due date';

        const priorityColors = { high: 'from-red-500 to-pink-500', medium: 'from-yellow-500 to-orange-500', low: 'from-green-500 to-teal-500' };
        const categoryIcons = { work: '💼', personal: '👤', health: '❤️‍🩹', shopping: '🛒' };
        const priorityIcons = { high: '🔴', medium: '🟡', low: '🟢' };

        return `
            <div class="task-item task-card rounded-2xl p-6 ${task.completed ? 'opacity-60' : ''} ${isOverdue ? 'ring-2 ring-red-500 animate-pulse' : ''}" data-task-id="${task.id}">
                <div class="flex items-start justify-between mb-4">
                    <div class="flex items-center space-x-4 flex-1">
                        <button onclick="taskManager.toggleTask('${task.id}')" class="mt-1 p-2 rounded-full transition-all duration-300 hover:scale-110 ${task.completed ? 'bg-green-500 text-white' : 'bg-white/10 text-white/60 hover:bg-green-500 hover:text-white'}">
                            <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>
                        </button>
                        <div class="flex-1">
                            <div class="flex items-center space-x-2 mb-2">
                                <span class="text-2xl">${categoryIcons[task.category]}</span>
                                <span class="px-3 py-1 bg-gradient-to-r ${priorityColors[task.priority]} text-white text-sm rounded-full font-medium">${priorityIcons[task.priority]} ${task.priority.toUpperCase()}</span>
                                ${isOverdue ? `<span class="px-2 py-1 bg-red-500 text-white text-xs rounded-full animate-pulse">OVERDUE</span>` : ''}
                            </div>
                            <h3 class="text-lg font-semibold text-white mb-2 ${task.completed ? 'line-through' : ''}">${task.text}</h3>
                        </div>
                    </div>
                    <div class="flex flex-col items-end space-y-2">
                        <button onclick="taskManager.editTask('${task.id}')" class="interactive-button p-2 bg-blue-500/20 text-blue-400 hover:bg-blue-500 hover:text-white rounded-xl"><svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"></path></svg></button>
                        <button onclick="taskManager.deleteTask('${task.id}')" class="interactive-button p-2 bg-red-500/20 text-red-400 hover:bg-red-500 hover:text-white rounded-xl"><svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clip-rule="evenodd"></path></svg></button>
                    </div>
                </div>
                <div class="text-sm text-white/60">Due: ${dueDate}</div>
            </div>
        `;
    }

    // --- Helper Functions ---
    getFilteredTasks() {
        let filtered = [...this.tasks];

        // Filter by search query
        if (this.searchQuery) {
            filtered = filtered.filter(task => task.text.toLowerCase().includes(this.searchQuery));
        }

        // Filter by status (all, pending, completed, overdue)
        const now = new Date();
        switch (this.currentFilter) {
            case 'completed': filtered = filtered.filter(task => task.completed); break;
            case 'pending': filtered = filtered.filter(task => !task.completed); break;
            case 'overdue': filtered = filtered.filter(task => !task.completed && task.dueDate && new Date(task.dueDate) < now); break;
        }

        // Sort the results
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        switch (this.currentSort) {
            case 'priority': filtered.sort((a, b) => priorityOrder[b.priority] - priorityOrder[a.priority]); break;
            case 'due': filtered.sort((a, b) => (a.dueDate && b.dueDate) ? new Date(a.dueDate) - new Date(b.dueDate) : a.dueDate ? -1 : 1); break;
            case 'alphabetical': filtered.sort((a, b) => a.text.localeCompare(b.text)); break;
            default: filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)); break;
        }
        return filtered;
    }
    
    updateStats() {
        const total = this.tasks.length;
        const completed = this.tasks.filter(t => t.completed).length;
        const pending = total - completed;
        
        document.getElementById('total-count').textContent = total;
        document.getElementById('completed-count').textContent = completed;
        document.getElementById('pending-count').textContent = pending;
        
        this.updateProgressRing('total-progress', total, total);
        this.updateProgressRing('completed-progress', completed, total);
        this.updateProgressRing('pending-progress', pending, total);
        
        this.updateFilterCounts();
    }
    
    updateFilterCounts() {
        document.getElementById('all-count').textContent = this.tasks.length;
        document.getElementById('pending-filter-count').textContent = this.tasks.filter(t => !t.completed).length;
        document.getElementById('completed-filter-count').textContent = this.tasks.filter(t => t.completed).length;
        document.getElementById('overdue-count').textContent = this.tasks.filter(t => !t.completed && t.dueDate && new Date(t.dueDate) < new Date()).length;
    }

    updateEmptyState(taskCount) {
        const emptyState = document.getElementById('empty-state');
        if (taskCount === 0) {
            let message = '';
            if (this.searchQuery) {
                message = `<h3 class="text-2xl font-bold text-white mb-4">No matching tasks found 🤷</h3><p class="text-white/70">Try a different search term.</p>`;
            } else {
                message = `<h3 class="text-2xl font-bold text-white mb-4">Ready to be productive? 🚀</h3><p class="text-white/70">Create your first task to get started!</p>`;
            }
            emptyState.innerHTML = message;
            emptyState.style.display = 'block';
        } else {
            emptyState.style.display = 'none';
        }
    }
    
    showAdvancedNotification(message, type = 'success') {
        // ... (The notification logic was correct and is kept the same)
    }

    resetForm() {
        this.taskForm.reset();
        this.editingTaskId = null;
        this.taskInput.focus();
        this.taskForm.querySelector('button[type="submit"] > span:first-child').textContent = 'Create Awesome Task';
    }

    // --- Local Storage and Initialization ---
    saveTasks() {
        try {
            localStorage.setItem('advanced-tasks', JSON.stringify(this.tasks));
        } catch (error) {
            console.error('Error saving tasks:', error);
            this.showAdvancedNotification('Failed to save tasks 😥', 'error');
        }
    }
    
    loadTasks() {
        try {
            const tasks = localStorage.getItem('advanced-tasks');
            return tasks ? JSON.parse(tasks) : [];
        } catch (error) {
            console.error('Error loading tasks:', error);
            return [];
        }
    }
    
    initializeTheme() {
        if (localStorage.getItem('theme') === 'light') {
            document.documentElement.classList.remove('dark');
        }
        this.updateFilterButtonStyles();
    }

    updateFilterButtonStyles() {
        const isDark = document.documentElement.classList.contains('dark');
        this.filterButtons.forEach(btn => {
            if (!btn.classList.contains('active')) {
                btn.className = `filter-btn interactive-button px-6 py-3 rounded-xl font-medium ${isDark ? 'bg-white/10 text-white/80 hover:bg-white/20' : 'bg-gray-200 text-gray-800 hover:bg-gray-300'}`;
            }
        });
    }

    saveAndRerender() {
        this.saveTasks();
        this.renderTasks();
    }
    
    // ... other methods like startVoiceSearch, handleKeyboard, etc.
}

// Initialize the app when the DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.taskManager = new AdvancedTaskManager();

    // Add sample tasks if the list is empty, for demonstration
    if (window.taskManager.tasks.length === 0) {
        const sampleTasks = [
            { text: "Complete the project presentation", priority: "high", category: "work", dueDate: new Date(Date.now() + 86400000).toISOString() },
            { text: "Go for a 30-minute run", priority: "medium", category: "health", dueDate: null },
            { text: "Buy groceries for the week", priority: "low", category: "shopping", dueDate: new Date(Date.now() + 2 * 86400000).toISOString() },
        ];
        sampleTasks.forEach(task => window.taskManager.addTask(task));
    }
});