// Data for all products
const products = [
    { id: 1, name: "iPhone 15 Pro Max", price: 1199, rating: 4.9, category: "Smartphones", brand: "Apple", image: "📱", badges: ["New", "Premium"], description: "Titanium design with A17 Pro chip", colors: ["Space Black", "Natural Titanium", "Blue Titanium"], stock: 15, popularity: 95 },
    { id: 2, name: "MacBook Pro M3", price: 1999, rating: 4.8, category: "Laptops", brand: "Apple", image: "💻", badges: ["New", "Popular"], description: "Revolutionary M3 chip performance", colors: ["Space Gray", "Silver"], stock: 8, popularity: 92 },
    { id: 3, name: "AirPods Pro 2", price: 249, rating: 4.7, category: "Audio", brand: "Apple", image: "🎧", badges: ["Sale", "Popular"], description: "Adaptive Transparency & Spatial Audio", colors: ["White"], stock: 25, popularity: 88 },
    { id: 6, name: "Samsung Galaxy S24 Ultra", price: 1299, rating: 4.7, category: "Smartphones", brand: "Samsung", image: "📱", badges: ["New", "Popular"], description: "AI-powered photography beast", colors: ["Titanium Gray", "Titanium Black"], stock: 18, popularity: 87 },
    { id: 7, name: "Dell XPS 15 OLED", price: 1899, rating: 4.5, category: "Laptops", brand: "Dell", image: "💻", badges: ["Premium"], description: "Stunning 4K OLED display", colors: ["Platinum Silver"], stock: 10, popularity: 78 },
    { id: 8, name: "Sony WH-1000XM5", price: 399, rating: 4.9, category: "Audio", brand: "Sony", image: "🎧", badges: ["Popular", "Sale"], description: "Industry-leading noise cancellation", colors: ["Black", "Silver"], stock: 22, popularity: 94 },
    { id: 12, name: "ASUS ROG Zephyrus G16", price: 2499, rating: 4.7, category: "Laptops", brand: "ASUS", image: "💻", badges: ["Premium", "Gaming"], description: "RTX 4080 gaming powerhouse", colors: ["Eclipse Gray"], stock: 5, popularity: 86 },
    { id: 17, name: "Razer Blade 16", price: 2799, rating: 4.5, category: "Laptops", brand: "Razer", image: "💻", badges: ["Premium", "Gaming"], description: "4K 120Hz OLED gaming laptop", colors: ["Black"], stock: 4, popularity: 81 }
];

// Central state for all active filters
let activeFilters = {
    categories: [], brands: [], minPrice: 0, maxPrice: 2000,
    minRating: 0, sort: 'popularity', search: '', quickFilter: null
};

// --- Main Application Logic ---
document.addEventListener('DOMContentLoaded', () => {
    setupFilters();
    setupEventListeners();
    renderProducts();
});

// Dynamically creates filter options from the product data
function setupFilters() {
    const categories = [...new Set(products.map(p => p.category))];
    const categoryContainer = document.getElementById('categoryFilters');
    categoryContainer.innerHTML = categories.map(category => 
        `<button class="filter-chip" onclick="toggleCategoryFilter('${category}', this)">${getCategoryIcon(category)} ${category}</button>`
    ).join('');

    const brands = [...new Set(products.map(p => p.brand))];
    const brandContainer = document.getElementById('brandFilters');
    brandContainer.innerHTML = brands.map(brand => `
        <label class="flex items-center space-x-2 cursor-pointer text-gray-300 hover:text-white">
            <input type="checkbox" onchange="updateBrandFilter('${brand}', this.checked)" class="form-checkbox h-4 w-4 rounded bg-card-bg border-neon-blue/50 text-neon-purple focus:ring-neon-purple">
            <span>${brand}</span>
        </label>
    `).join('');

    const ratingContainer = document.getElementById('ratingFilters');
    ratingContainer.innerHTML = [4, 4.5].map(rating =>
        `<button onclick="setMinRating(${rating}, this)" class="filter-chip flex-1">${rating}+ ⭐</button>`
    ).join('');
}

// Sets up all event listeners for UI elements
function setupEventListeners() {
    document.getElementById('sortSelect').addEventListener('change', e => {
        activeFilters.sort = e.target.value;
        applyFiltersAndSort();
    });
    document.getElementById('searchInput').addEventListener('input', debounce(e => {
        activeFilters.search = e.target.value.toLowerCase();
        applyFiltersAndSort();
    }, 300));
    document.getElementById('priceRange').addEventListener('input', e => {
        const value = parseInt(e.target.value);
        document.getElementById('priceValue').textContent = value >= 2000 ? '$2000+' : `$${value}`;
        activeFilters.maxPrice = value >= 2000 ? 2001 : value; // Use 2001 to include 2000
        applyFiltersAndSort();
    });
}

// --- Filter & Sort Logic ---
function applyFiltersAndSort() {
    let filtered = [...products];
    const now = new Date();

    // Apply all filters
    filtered = filtered.filter(p => 
        (activeFilters.search === '' || p.name.toLowerCase().includes(activeFilters.search) || p.description.toLowerCase().includes(activeFilters.search)) &&
        (activeFilters.categories.length === 0 || activeFilters.categories.includes(p.category)) &&
        (activeFilters.brands.length === 0 || activeFilters.brands.includes(p.brand)) &&
        (p.price <= activeFilters.maxPrice) &&
        (p.rating >= activeFilters.minRating) &&
        (!activeFilters.quickFilter || p.badges.includes(activeFilters.quickFilter.charAt(0).toUpperCase() + activeFilters.quickFilter.slice(1)))
    );

    // Apply sorting
    switch (activeFilters.sort) {
        case 'name-asc': filtered.sort((a, b) => a.name.localeCompare(b.name)); break;
        case 'name-desc': filtered.sort((a, b) => b.name.localeCompare(a.name)); break;
        case 'price-asc': filtered.sort((a, b) => a.price - b.price); break;
        case 'price-desc': filtered.sort((a, b) => b.price - a.price); break;
        case 'rating-desc': filtered.sort((a, b) => b.rating - a.rating); break;
        case 'popularity': filtered.sort((a, b) => b.popularity - a.popularity); break;
        case 'newest': filtered.sort((a, b) => b.id - a.id); break;
    }
    
    renderProducts(filtered);
}

// --- UI Rendering ---
function renderProducts(filteredProducts) {
    const grid = document.getElementById('productGrid');
    const noResults = document.getElementById('noResults');
    document.getElementById('productCount').textContent = `${filteredProducts.length} Products`;
    
    if (filteredProducts.length === 0) {
        grid.innerHTML = '';
        noResults.classList.remove('hidden');
    } else {
        noResults.classList.add('hidden');
        grid.innerHTML = filteredProducts.map((product, index) => 
            `
            <div class="product-card" style="animation-delay: ${index * 0.05}s;">
                <div class="relative p-4">
                    <div class="absolute top-3 left-3 flex flex-wrap gap-1 z-10">
                        ${product.badges.map(badge => `<span class="px-2 py-1 text-xs font-bold rounded-full ${getBadgeStyle(badge)}">${getBadgeIcon(badge)} ${badge}</span>`).join('')}
                    </div>
                    <div class="text-center my-4">
                        <span class="text-6xl animate-float" style="animation-delay: ${index * 0.2}s;">${product.image}</span>
                    </div>
                    <div>
                        <h3 class="font-bold text-lg text-white mb-1 hover:text-neon-blue transition-colors cursor-pointer">${product.name}</h3>
                        <p class="text-xs text-neon-purple font-medium">${product.brand}</p>
                        <div class="flex items-center justify-between my-3">
                            <div class="flex items-center space-x-1">${generateStars(product.rating)}<span class="text-sm text-gray-400 ml-1">(${product.rating})</span></div>
                            <div class="text-xs text-gray-500"><i class="fas fa-box mr-1"></i>${product.stock} left</div>
                        </div>
                        <div class="flex items-center justify-between pt-3 border-t border-white/10">
                            <span class="text-2xl font-black cyber-font bg-gradient-to-r from-accent-gold to-neon-blue bg-clip-text text-transparent">$${product.price.toLocaleString()}</span>
                            <button class="bg-gradient-to-r from-neon-blue to-neon-purple px-4 py-2 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-neon-blue/30"><i class="fas fa-cart-plus mr-2"></i>Add</button>
                        </div>
                    </div>
                </div>
            </div>
            `
        ).join('');
    }
}

// --- UI Interaction Handlers ---
function toggleCategoryFilter(category, element) {
    const index = activeFilters.categories.indexOf(category);
    if (index > -1) {
        activeFilters.categories.splice(index, 1);
        element.classList.remove('active');
    } else {
        activeFilters.categories.push(category);
        element.classList.add('active');
    }
    applyFiltersAndSort();
}
function updateBrandFilter(brand, isChecked) {
    const index = activeFilters.brands.indexOf(brand);
    if (isChecked && index === -1) {
        activeFilters.brands.push(brand);
    } else if (!isChecked && index > -1) {
        activeFilters.brands.splice(index, 1);
    }
    applyFiltersAndSort();
}
function setMinRating(rating, element) {
    activeFilters.minRating = activeFilters.minRating === rating ? 0 : rating;
    document.querySelectorAll('#ratingFilters button').forEach(btn => btn.classList.remove('active'));
    if (activeFilters.minRating === rating) element.classList.add('active');
    applyFiltersAndSort();
}
function clearAllFilters() {
    activeFilters = { categories: [], brands: [], minPrice: 0, maxPrice: 2000, minRating: 0, sort: 'popularity', search: '', quickFilter: null };
    document.getElementById('searchInput').value = '';
    document.getElementById('sortSelect').value = 'popularity';
    document.getElementById('priceRange').value = 2000;
    document.getElementById('priceValue').textContent = '$2000+';
    document.querySelectorAll('#categoryFilters button, #ratingFilters button').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('#brandFilters input').forEach(cb => cb.checked = false);
    applyFiltersAndSort();
}
function toggleFilters() {
    document.getElementById('filterSidebar').classList.toggle('hidden');
}

// --- Helper & Utility Functions ---
function getCategoryIcon(category) {
    const icons = { 'Smartphones': '📱', 'Laptops': '💻', 'Audio': '🎧', 'Tablets': '📝', 'Wearables': '⌚' };
    return icons[category] || '📦';
}
function getBadgeStyle(badge) {
    const styles = { 'New': 'bg-blue-500/30 text-blue-300', 'Sale': 'bg-red-500/30 text-red-300', 'Popular': 'bg-purple-500/30 text-purple-300', 'Premium': 'bg-yellow-500/30 text-yellow-300', 'Gaming': 'bg-green-500/30 text-green-300' };
    return styles[badge] || 'bg-gray-500/30 text-gray-300';
}
function getBadgeIcon(badge) {
    const icons = { 'New': '✨', 'Sale': '🔥', 'Popular': '⭐', 'Premium': '💎', 'Gaming': '🎮' };
    return icons[badge] || '';
}
function generateStars(rating) {
    let stars = '';
    for (let i = 1; i <= 5; i++) {
        if (i <= rating) stars += '<i class="fas fa-star text-yellow-400"></i>';
        else if (i - 0.5 <= rating) stars += '<i class="fas fa-star-half-alt text-yellow-400"></i>';
        else stars += '<i class="far fa-star text-gray-600"></i>';
    }
    return stars;
}
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}