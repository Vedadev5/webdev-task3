document.addEventListener('DOMContentLoaded', () => {

    // Mobile Menu Toggle
    const menuToggle = document.getElementById('menu-toggle');
    const menu = document.getElementById('menu');
    if (menuToggle && menu) {
        menuToggle.addEventListener('click', () => {
            menu.classList.toggle('hidden');
        });
    }

    // Intersection Observer for fade-in animations on scroll
    const sections = document.querySelectorAll('.section-fade');
    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    sections.forEach(section => observer.observe(section));

    // Active Navigation Link Highlighting on Scroll
    const navLinks = document.querySelectorAll('.nav-link');
    window.addEventListener('scroll', () => {
        let current = '';
        document.querySelectorAll('section').forEach(section => {
            const sectionTop = section.offsetTop;
            if (pageYOffset >= sectionTop - 150) {
                current = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').includes(current)) {
                link.classList.add('active');
            }
        });
    });

    // Contact Form Submission
    const contactForm = document.getElementById('contact-form');
    const formSuccess = document.getElementById('form-success');
    if (contactForm && formSuccess) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            formSuccess.classList.remove('hidden');
            contactForm.reset();
            setTimeout(() => {
                formSuccess.classList.add('hidden');
            }, 5000);
        });
    }

    // Typing Effect for Hero Section
    const typingText = document.getElementById('typing-text');
    if (typingText) {
        const phrases = ['Web and App Developer', 'UI/UX Designer', 'Problem Solver', 'Creative Thinker'];
        let phraseIndex = 0;
        let charIndex = 0;
        let isDeleting = false;

        function typeEffect() {
            const currentPhrase = phrases[phraseIndex];
            const typeSpeed = isDeleting ? 50 : 100;
            typingText.textContent = currentPhrase.substring(0, charIndex);

            if (isDeleting) {
                charIndex--;
            } else {
                charIndex++;
            }

            if (!isDeleting && charIndex === currentPhrase.length + 1) {
                isDeleting = true;
                setTimeout(typeEffect, 2000); // Pause at end of word
                return;
            } else if (isDeleting && charIndex === 0) {
                isDeleting = false;
                phraseIndex = (phraseIndex + 1) % phrases.length;
                setTimeout(typeEffect, 500); // Pause before new word
                return;
            }
            setTimeout(typeEffect, typeSpeed);
        }
        setTimeout(typeEffect, 500);
    }

    // Animate Progress Bars when in view
    const progressObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const bar = entry.target;
                const targetWidth = bar.getAttribute('data-width');
                bar.style.width = targetWidth;
                observer.unobserve(bar);
            }
        });
    }, { threshold: 0.5 });
    document.querySelectorAll('.progress-fill').forEach(bar => progressObserver.observe(bar));

    // Animate Counters when in view
    const counterObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counter = entry.target;
                const target = +counter.getAttribute('data-target');
                const duration = 2000;
                const stepTime = Math.abs(Math.floor(duration / target));
                let current = 0;

                const timer = setInterval(() => {
                    current += 1;
                    counter.innerText = current;
                    if (current == target) {
                        clearInterval(timer);
                    }
                }, stepTime);
                observer.unobserve(counter);
            }
        });
    }, { threshold: 0.8 });
    document.querySelectorAll('.counter').forEach(counter => counterObserver.observe(counter));

    // Confetti Effect for Achievement Cards
    const achievementCards = document.querySelectorAll('.achievement-card');
    achievementCards.forEach(card => {
        card.addEventListener('mouseenter', () => createConfetti(card));
    });

    function createConfetti(element) {
        const confettiCount = 20;
        const colors = ['#4F46E5', '#7C3AED', '#60A5FA', '#34D399', '#F472B6'];
        const container = element.querySelector('.glow-on-hover') || element;
        const containerRect = container.getBoundingClientRect();
        
        for (let i = 0; i < confettiCount; i++) {
            const confetti = document.createElement('div');
            confetti.classList.add('confetti');
            const size = Math.random() * 8 + 4;
            confetti.style.width = `${size}px`;
            confetti.style.height = `${size}px`;
            confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
            confetti.style.position = 'absolute';
            confetti.style.top = `${containerRect.height / 2}px`;
            confetti.style.left = `${containerRect.width / 2}px`;
            
            element.appendChild(confetti);

            setTimeout(() => {
                confetti.style.opacity = '1';
                const transform = `translate(${(Math.random() - 0.5) * 200}px, ${(Math.random() - 0.5) * 200}px) rotate(${Math.random() * 360}deg) scale(0)`;
                confetti.style.transform = transform;
                confetti.style.transition = 'transform 1s ease-out, opacity 1s ease-out';
                setTimeout(() => confetti.remove(), 1000);
            }, 10);
        }
    }
});